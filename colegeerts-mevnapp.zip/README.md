# MEVN Stack App

This is a project to fulfill integrated requirements between classes for my IMS program. It is written with the MEVN stack (Mongo, Express, Vue, Node) and is a small recipe saving application for sharing and saving your favorite recipes!
